function Contact() {

    return (
        <>
            <h1>This is the Contact Page</h1>
        </>
    )
}

export default Contact;