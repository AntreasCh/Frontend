import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import ParentPage from './ParentPage';
import '../styles/AddCard.css';

/**
 * AddCard component that adds a new card into one of the 
 * three categories and handles the input data to be valid.
 * 
 * @author Alexantros Tamboutsiaris W20001556
 */
function AddCard({ path_title }) {

    // Declare state variable to track whether to show confirmation message
    const [showConfirmation, setShowConfirmation] = useState(false);

    // Declare state variables for the 'news','relevant' and 'industry' data
    const [newsTitle, setNewsTitle] = useState("");
    const [newsContent, setNewsContent] = useState("");
    const [newsImgURL, setNewsImgURL] = useState("");
    const [articleTitle, setArticleTitle] = useState("");
    const [articleContent, setArticleContent] = useState("");
    const [articleImgURL, setArticleImgURL] = useState("");
    const [relevantTitle, setRelevantTitle] = useState("");
    const [relevantContent, setRelevantContent] = useState("");
    const [relevantImgURL, setRelevantImgURL] = useState("");
    const [articleURL, setArticleURL] = useState("");
    const [industryTitle, setIndustryTitle] = useState("");
    const [industryImgURL, setIndustryImgURL] = useState("");

    // Function to add a new card
    function addCard() {

        // Create a new FormData object
        const formData = new FormData();

        // Add data to the formData object using the append method
        formData.append('news_title', newsTitle);
        formData.append('news_content', newsContent);
        formData.append('news_Img_url', newsImgURL);
        formData.append('article_title', articleTitle);
        formData.append('article_content', articleContent);
        formData.append('article_Img_url', articleImgURL);
        formData.append('date_published', new Date().toLocaleDateString('en-US'));
        formData.append('relevant_title', relevantTitle);
        formData.append('relevant_content', relevantContent);
        formData.append('relevant_Img_url', relevantImgURL);
        formData.append('article_url', articleURL);
        formData.append('industry_title', industryTitle);
        formData.append('industry_Img_url', industryImgURL);

        // Add the card to the API
        fetch("http://unn-w20017219.newnumyspace.co.uk/ic3/api/resources/" + path_title + "/add", {
            method: 'POST',
            body: formData
        })
            .then((response) => {
                if (!response.ok) {
                    throw new Error('The data cannot be added');
                }
                alert('The card has been added successfully. Please go back to see the new card.');
            })
            .catch((error) => {
                console.error('Error reason:', error);
            });
    }

    // Function to check if there are empty fields
    function handleAdd() {

        if (path_title === "news-and-insights") {
            if (newsTitle === "" || newsContent === "" || newsImgURL === "" ||
                articleTitle === "" || articleContent === "" || articleImgURL === "") {
                setShowConfirmation(false);
                alert("Please fill out all required fields.");
                return;
            } else {
                setShowConfirmation(true);
            }
        }
        else if (path_title === "relevant-news-stories") {
            if (relevantTitle === "" || relevantContent === "" || relevantImgURL === "" ||
                articleURL === "") {
                setShowConfirmation(false);
                alert("Please fill out all required fields.");
                return;
            } else {
                setShowConfirmation(true);
            }
        }
        else if (path_title === "industry-reports") {
            if (industryTitle === "" || industryImgURL === "" || articleURL === "") {
                setShowConfirmation(false);
                alert("Please fill out all required fields.");
                return;
            } else {
                setShowConfirmation(true);
            }
        }
    }

    // If the user clicks 'yes', it will enter the 'addCard' function
    function handleConfirmation(value) {
        setShowConfirmation(false);
        if (value === 'yes') {
            addCard();
        }
    }

    // Function to check the number of the characters 
    function maxNewsTitleChar(e) {
        const inputValue = e.target.value;
        if (inputValue.length < 65) {
            setNewsTitle(inputValue);
        }
    }

    // Function to check the number of the characters 
    function maxNewsContentChar(e) {
        const inputValue = e.target.value;
        if (inputValue.length < 140) {
            setNewsContent(inputValue);
        }
    }

    // Function to check the number of the characters 
    function maxArticleTitleChar(e) {
        const inputValue = e.target.value;
        if (inputValue.length < 110) {
            setArticleTitle(inputValue);
        }
    }

    // Function to replace '\n' with '\\n' (for new line)
    function replaceSymbol(e) {
        const inputValue = e.target.value;
        const replacedValue = inputValue.replace(/\n/g, '\\n');
        setArticleContent(replacedValue);
    }

    // Function to check the number of the characters 
    function maxRelevantTitleChar(e) {
        const inputValue = e.target.value;
        if (inputValue.length < 65) {
            setRelevantTitle(inputValue);
        }
    }

    // Function to check the number of the characters 
    function maxRelevantContentChar(e) {
        const inputValue = e.target.value;
        if (inputValue.length < 140) {
            setRelevantContent(inputValue);
        }
    }

    // Function to check the number of the characters 
    function maxIndustryTitleChar(e) {
        const inputValue = e.target.value;
        if (inputValue.length < 65) {
            setIndustryTitle(inputValue);
        }
    }

    return (
        <ParentPage>
        <div>
            {path_title === "news-and-insights" &&
                <div>
                  
                    <div className="addHero">
                        <img alt="AddCardHeroImg" src="http://unn-w20001556.newnumyspace.co.uk/IC3_Images/Hero_Images/addCardHero.jpg" />
                    </div>
                    <div className="addTitle">
                        <h1>Insert a new card on the <span className="addPathTitle">News and Insights</span> page</h1>
                    </div>
                    <div className="insertForm">
                        <label>
                            Card Title <span className="required">* Required</span>
                            <input type="text" placeholder="No more than 65 characters"
                                onChange={(e) => maxNewsTitleChar(e)} maxLength={65} />
                        </label>
                        <label>
                            Card Content <span className="required">* Required</span>
                            <textarea name="cardContent" rows="2" placeholder="No more than 140 characters"
                                onChange={(e) => maxNewsContentChar(e)} maxLength={140} />
                        </label>
                        <label>
                            URL Address of Card Image <span className="required">* Required</span>
                            <input type="text" placeholder="Please insert a valid image address"
                                onChange={(e) => setNewsImgURL(e.target.value)} />
                        </label>
                        <label>
                            Article Title <span className="required">* Required</span>
                            <input type="text" placeholder="No more than 110 characters"
                                onChange={(e) => maxArticleTitleChar(e)} maxLength={110} />
                        </label>
                        <label>
                            Article Content <span className="required">* Required</span>
                            <textarea name="articleContent" rows="10"
                                onChange={replaceSymbol} />
                        </label>
                        <label>
                            URL Address of Article Image<span className="required">* Required</span>
                            <input type="text" placeholder="Please insert a valid image URL address"
                                onChange={(e) => setArticleImgURL(e.target.value)} />
                        </label>
                        <div className="addBtns">
                            <Link to="/resources/news-and-insights" className="link">
                                <button>Back</button>
                            </Link>
                            <button onClick={handleAdd}>Add Card</button>
                        </div>
                    </div>
                    {showConfirmation && (
                        <div className="addNotification">
                            <p>Are you sure you want to add the card?</p>
                            <div>
                                <button onClick={() => handleConfirmation('yes')}>Yes</button>
                                <button onClick={() => handleConfirmation('no')}>No</button>
                            </div>
                        </div>
                    )}
                </div>
            }
            {path_title === "relevant-news-stories" &&
                <div>
                    
                    <div className="addHero">
                        <img alt="AddCardHeroImg" src="http://unn-w20001556.newnumyspace.co.uk/IC3_Images/Hero_Images/addCardHero.jpg" />
                    </div>
                    <div className="addTitle">
                        <h1>Insert a new card on the <span className="addPathTitle">Relevant News Stories</span> page</h1>
                    </div>
                    <div className="insertForm">
                        <label>
                            Card Title <span className="required">* Required</span>
                            <input type="text" placeholder="No more than 65 characters"
                                onChange={(e) => maxRelevantTitleChar(e)} maxLength={65} />
                        </label>
                        <label>
                            Card Content <span className="required">* Required</span>
                            <textarea name="cardContent" rows="2" placeholder="No more than 140 characters"
                                onChange={(e) => maxRelevantContentChar(e)} maxLength={140} />
                        </label>
                        <label>
                            URL Address of Card Image<span className="required">* Required</span>
                            <input type="text" placeholder="Please insert a valid image URL address"
                                onChange={(e) => setRelevantImgURL(e.target.value)} />
                        </label>
                        <label>
                            URL Address of article<span className="required">* Required</span>
                            <input type="text" placeholder="Please insert a valid article URL address"
                                onChange={(e) => setArticleURL(e.target.value)} />
                        </label>
                        <div className="addBtns">
                            <Link to="/resources/relevant-news-stories" className="link">
                                <button>Back</button>
                            </Link>
                            <button onClick={handleAdd}>Add Card</button>
                        </div>
                    </div>
                    {showConfirmation && (
                        <div className="addNotification">
                            <p>Are you sure you want to add the card?</p>
                            <div>
                                <button onClick={() => handleConfirmation('yes')}>Yes</button>
                                <button onClick={() => handleConfirmation('no')}>No</button>
                            </div>
                        </div>
                    )}
                </div>
            }
            {path_title === "industry-reports" &&
                <div>
                
                    <div className="addHero">
                        <img alt="AddCardHeroImg" src="http://unn-w20001556.newnumyspace.co.uk/IC3_Images/Hero_Images/addCardHero.jpg" />
                    </div>
                    <div className="addTitle">
                        <h1>Insert a new card on the <span className="addPathTitle">Industry Reports</span> page</h1>
                    </div>
                    <div className="insertForm">
                        <label>
                            Card Title <span className="required">* Required</span>
                            <input type="text" placeholder="No more than 65 characters"
                                onChange={(e) => maxIndustryTitleChar(e)} maxLength={65} />
                        </label>
                        <label>
                            URL Address of Card Image<span className="required">* Required</span>
                            <input type="text" placeholder="Please insert a valid image URL address"
                                onChange={(e) => setIndustryImgURL(e.target.value)} />
                        </label>
                        <label>
                            URL Address of partner's script <span className="required">* Required</span>
                            <input type="text" placeholder="Please insert a valid URL address"
                                onChange={(e) => setArticleURL(e.target.value)} />
                        </label>
                        <div className="addBtns">
                            <Link to="/resources/industry-reports" className="link">
                                <button>Back</button>
                            </Link>
                            <button onClick={handleAdd}>Add Card</button>
                        </div>
                    </div>
                    {showConfirmation && (
                        <div className="addNotification">
                            <p>Are you sure you want to add the card?</p>
                            <div>
                                <button onClick={() => handleConfirmation('yes')}>Yes</button>
                                <button onClick={() => handleConfirmation('no')}>No</button>
                            </div>
                        </div>
                    )}
                </div>
            }
        </div>
        </ParentPage>
    );
}

export default AddCard;
