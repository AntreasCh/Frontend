<?php
 
namespace FirebaseJWT;
 
class BeforeValidException extends \UnexpectedValueException
{
}