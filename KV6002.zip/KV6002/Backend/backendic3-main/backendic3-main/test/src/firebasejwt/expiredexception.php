<?php
 
namespace FirebaseJWT;
 
class ExpiredException extends \UnexpectedValueException
{
}