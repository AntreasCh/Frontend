Names:
========
Antreas Chrystodoulou
Panagiotis Tsellos
Dimitriana Stylianou
Alexantros Tamboutsiaris
Panagiotis Tamboukaris

Team:
=====
 CV8

Project:
========
 IC3 website

Login details: 
==============
1. to log in as admin, username= admin, password=admin.   
2. To log in as user username=joe, password =joe

Pre-install libraries in terminal:
==================================
- npm install node modules
- npm install react-router-dom
- npm install moment
- npm install axios
- npm install react spring
- npm i swiper
- npm i @emotion/styled
- npm i @emotion/css
- npm add @emotion/react

To start-up:
============
Find the right path into powershell and then use the command: 
- npm start 

Github URLs: 
============
1. React: https://github.com/AntreasCh/Frontend
2. API: https://github.com/tpanayiotis/backendic3

Access emails after they are sent from the contact form:

Email adress:
=============
kv6002group@gmail.com

Email password:
===============
Kv6002Group!
